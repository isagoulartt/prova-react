import React from 'react';
import Navbar from './Navbar';


export default function Header(){
    return(
        <header className='header container'>
            <div className="logo">
                <p>  </p>
                <img src="logo-branco-senai.png"></img>
            </div>
            <Navbar />
        </header>
    )
}