import React from 'react';
import TextBig from './TextBig';
import Button from './Button';


export default function Banner(){
    return(
        <div className='banner container'>
            <div className="two-column content">
    
                <img src="sesi.jpeg" />
            </div>
            
            <div className="two-column content">
                    <TextBig label="A mostra steam é um evento voltado para os alunos apresentarem algum projeto que desenvolveram ao decorrer do ano ou até mesmo criar um novo projeto."/>
            </div>
            <div className="two-column content">
            <div className="two-column content">
                    <TextBig label=""/>
            </div>
            </div>
            <div className="two-column content">
                    <TextBig label="Venha participar!  Dia:28/09/2024 Apartir das 8h da manhã  Local: Rodovia BR 101 nº km 211, 7235 - Distrito Industrial, São José - SC"/>
            </div>
            
        </div>
    )
}