import React from 'react';
import ItemImg from './ItemImg';
import TextBig from './TextBig';
import Button from './Button';


export default function Galery(){
    return(
        <div className="one-column content">
            <TextBig label="Conheça mais" />
            <div className="inner-container">
                <ItemImg src="fogo.png"label="fogo"/>
                <ItemImg src="carineluciano.png" label="a"/>
                <ItemImg src= "mar.png" label="mar"/>
                <ItemImg src="sis.png" label="sis"/>
                <ItemImg src="app.png" label="app"/>
                <ItemImg src="nhe.png" label="b"/>
               
            
            </div>
            
        </div>
    )
}