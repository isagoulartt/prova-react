import React from 'react';
import Navbar from './Navbar';


export default function Footer(){
    return(
        <footer className='footer container'>
            <div className="nome">
                <p> Isabely Amábile Goulart 3°C</p>
            </div>
            <Navbar />
        </footer>
    )
}